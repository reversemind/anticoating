import ru.teligent.p90.jvm.common.*


P90TPTF tptf = new P90TPTF()
println "tptf:" + tptf
println "other:" + tptf.getTimeStamp()
